#!/bin/sh

echo -e "\nPassword: `cat pass.txt`\n"
sudo openvpn --config office.ovpn
